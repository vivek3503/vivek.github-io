from django.contrib import admin
from.models import*

# Register your models here.

admin.site.register(contact_up)
admin.site.register(user)
admin.site.register(Add_product)